package View;

import java.lang.Exception;

import javax.swing.JFrame;

public class MovimentacaoInvalidaException extends Exception {

	public MovimentacaoInvalidaException(String mensagem) {
        super(mensagem);
    }


	
    
}
